﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Microsoft.Win32;
using static System.Net.Mime.MediaTypeNames;
using System.Reflection;
using System.Threading;
using Application = System.Windows.Forms.Application;

namespace Project_Feladat1
{
    public partial class Form1 : Form
    {
        public StreamWriter file1 = File.AppendText("log.txt"); // Log fájl létrehozása/log fájl olvasása hamár létezik.
        
        public Form1()
        {
            InitializeComponent();
            
            try
            {
                var path = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run";
                RegistryKey key = Registry.CurrentUser.OpenSubKey(path, true); // regisztrihez adás a windows automatikus indítása miatt.
                key.SetValue("MyApplication", Application.ExecutablePath.ToString());
               
                file1.WriteLine(DateTime.Now + " Program elindult");
                file1.Flush();
             
               

            }
            catch (Exception ex)
            {

                file1.WriteLine(DateTime.Now + " Hiba: " + Environment.NewLine + ex.ToString()); //Hiba logba írás.
                file1.Flush();

            }     
           
        }

       
        protected override void OnFormClosing(FormClosingEventArgs e) //Form manuális bezárásának érzékelése.
        {
            if (systemShutdown == false) // Mivel a windows bezárásánál a program a WM_QUERYENDSESSION kiküldése után a manuális bezárást is érzékelés ezért szükséges az If systemshutdown == false
            {

            
                file1.WriteLine(DateTime.Now + " Felhasználó bezárta a programot");
                file1.Flush();
                base.OnFormClosing(e);
                Dispose(true);

                Thread.Sleep(5000);//t
                Application.Restart(); // Form újraindítása
                
            }
        }

        private static int WM_QUERYENDSESSION = 0x11; //Windows leállás érzékelése
        public static bool systemShutdown = false; 
        protected override void WndProc(ref System.Windows.Forms.Message m)
        {
            if (m.Msg == WM_QUERYENDSESSION)
            {
            
                file1.WriteLine(DateTime.Now + " Windows leállás miatt állt le a program");
                file1.Flush();


                 systemShutdown = true;
            }

            
            base.WndProc(ref m);

        } 
        
        //A program észrevétlen háttérben futása // nem lett megvalósítva.
        private void Form1_Shown(object sender, EventArgs e)
        {
            //this.Hide();
        }

    }
}
